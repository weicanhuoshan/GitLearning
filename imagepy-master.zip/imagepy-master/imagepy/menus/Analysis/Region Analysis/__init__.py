#
catlog = ['regionprops_plgs', '-', 'statistic_plgs']