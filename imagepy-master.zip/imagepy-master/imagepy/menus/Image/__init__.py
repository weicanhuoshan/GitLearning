catlog = ['Type', '-', 'Adjust', 'Color', 'Stack', 'Transform', '-', 'duplicate_plg',  
          'crop_plg', 'canvassize_plg', 'resize_plg', '-', 'setscale_plg', 'Lookup table']