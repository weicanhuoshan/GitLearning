catlog = ['surface2d_plg', 'surface3d_plg', 
          '-', '2DSurface Demo.mc']