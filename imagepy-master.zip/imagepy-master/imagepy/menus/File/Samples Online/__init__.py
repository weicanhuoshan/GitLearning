# -*- coding: utf-8 -*-
"""
Created on Wed Jan 18 13:31:36 2017
@author: yxl
"""

catlog = ['Lena', 'Two Boxes', 'DEM', '-', 'Logo', 'Author']