'''
Package:File
    Author: yxdragon
    E-main: imagepy@sina.com
    Function:open, save, import, export, open url...
'''
### TODO: Fixme! In this directory, many path should be corrected?!
catlog = ['new_plg', '-', 'open_plg', 'save_plg', '-', 'Open Recent', 'Samples Local', 'Samples Online',  
	'-', 'Import', 'Export', '-', 'BMP', 'JPG', 'PNG', 'TIF', 'GIF', '-', 'exit_plg']