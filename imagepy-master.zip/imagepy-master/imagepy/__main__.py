import sys
sys.path.append('..')
import imagepy
imagepy.show()