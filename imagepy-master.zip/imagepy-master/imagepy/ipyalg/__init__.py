from .hydrology.findmax import find_maximum
from .hydrology.ridge import ridge
from .hydrology.isoline import stair, isoline