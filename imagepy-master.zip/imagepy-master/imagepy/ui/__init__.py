'''
from __future__ import absolute_import
from . import canvasframe
from . import panelconfig
from . import widgets
from . import canvas
from . import logwindow
from . import plotwindow
from . import tablewindow
from . import imagepy
from . import macroseditor
from . import pluginloader
from . import toolsloader
'''