catlog = ['Add Slice', 'Delete Slice',
          'Previous Slice', 'Next Slice', 
          'Set Slice', 'Orthogonal View']