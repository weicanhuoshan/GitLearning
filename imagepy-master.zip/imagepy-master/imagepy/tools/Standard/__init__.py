# import os
# catlog = [name[:-3] for name in os.listdir() if name.endswith( "_tol.py")]
catlog=['rectangle_tol','oval_tol','polygon_tol',
'freearea_tol','line_tol','freeline_tol','point_tol','magic_tol',
'scale_tol','move_tol','painter_tol','colorpicker_tol']