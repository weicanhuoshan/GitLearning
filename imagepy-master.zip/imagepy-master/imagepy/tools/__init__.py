catlog = ['Standard','Transform','Stack','Draw']
