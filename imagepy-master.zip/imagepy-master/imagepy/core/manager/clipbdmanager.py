# -*- coding: utf-8 -*-
"""
Created on Sun Jan 15 01:10:37 2017
@author: yxl
"""
class ClipBoardManager:
    roi = None
    img = None