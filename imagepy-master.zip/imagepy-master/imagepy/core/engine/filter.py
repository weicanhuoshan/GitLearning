# -*- coding: utf-8 -*-
"""
Created on Fri Dec  2 23:48:33 2016
@author: yxl
"""

import wx
import threading
import numpy as np

from ... import IPy
from ...ui.panelconfig import ParaDialog
from ...core.manager import TextLogManager, WindowsManager, TaskManager
        
def process_channels(plg, ips, src, des, para):
    if ips.channels>1 and not 'not_channel' in plg.note:
        for i in range(ips.channels):
            rst = plg.run(ips, src if src is None else src[:,:,i], des[:,:,i], para)
            if not rst is des and not rst is None:
                des[:,:,i] = rst
    else:
        rst = plg.run(ips, src, des, para)
        if not rst is des and not rst is None:
            des[:] = rst
    return des

def process_one(plg, ips, src, img, para, callafter=None):
    TaskManager.add(plg)
    transint = '2int' in plg.note and ips.dtype == np.uint8
    transfloat = '2float' in plg.note and not ips.dtype in (np.float32, np.float64)
    if transint: buf =  img.astype(np.int32)
    if transfloat: buf = img.astype(np.float32)
    rst = process_channels(plg, ips, src, buf if transint or transfloat else img, para)
    if not img is rst and not rst is None:
        np.clip(rst, ips.range[0], ips.range[1], out=img)
    if 'auto_msk' in plg.note and not ips.get_msk() is None:
        msk = True ^ ips.get_msk()
        img[msk] = src[msk]
    ips.update = 'pix'
    TaskManager.remove(plg)
    if not callafter is None:callafter()
    
def process_stack(plg, ips, src, imgs, para):
    TaskManager.add(plg)
    from time import time, sleep
    start = time()
    transint = '2int' in plg.note and ips.dtype == np.uint8
    transfloat = '2float' in plg.note and not ips.dtype in (np.float32, np.float64)
    if transint: buf =  imgs[0].astype(np.int32)
    if transfloat: buf = imgs[0].astype(np.float32)
    for i,n in zip(imgs,list(range(len(imgs)))):
        #sleep(0.5)
        plg.progress(n, len(imgs))
        if 'auto_snap' in plg.note : src[:] = i
        if transint or transfloat: buf[:] = i
        rst = process_channels(plg, ips, src, buf if transint or transfloat else i, para)
        if not i is rst and not rst is None:
            np.clip(rst, ips.range[0], ips.range[1], out=i)
        if 'auto_msk' in plg.note and not ips.get_msk() is None:
            msk = True ^ ips.get_msk()
            i[msk] = src[msk]
    ips.update = 'pix'
    TaskManager.remove(plg)
    
class Filter:
    title = 'Filter'
    modal = True
    note = []
    'all, 8_bit, 16_bit, rgb, float, not_channel, not_slice, req_roi, auto_snap, auto_msk, preview, 2int, 2float'
    para = None
    view = None
    prgs = (None, 1)

    def __init__(self, ips=None):
        if ips==None:ips = IPy.get_ips()
        self.dialog = None
        self.ips = ips
        
    def progress(self, i, n):
        self.prgs = (i, n)

    def show(self):
        self.dialog = ParaDialog(WindowsManager.get(), self.title)
        self.dialog.init_view(self.view, self.para, 'preview' in self.note, modal=self.modal)
        self.dialog.set_handle(lambda x:self.preview(self.para))
        if self.modal: return self.dialog.ShowModal()
        self.dialog.on_ok = lambda : self.ok(self.ips)
        self.dialog.on_cancel = lambda : self.cancel(self.ips)
        self.dialog.Show()
    
    def run(self, ips, snap, img, para = None):
        return 255-img
        
    def check(self, ips):
        note = self.note
        if ips == None:
            IPy.alert('no image opened!')
            return False
        elif 'req_roi' in note and ips.roi == None:
            IPy.alert('no Roi found!')
            return False
        elif not 'all' in note:
            if ips.get_imgtype()=='rgb' and not 'rgb' in note:
                IPy.alert('do not surport rgb image')
                return False
            elif ips.get_imgtype()=='8-bit' and not '8-bit' in note:
                IPy.alert('do not surport 8-bit image')
                return False
            elif ips.get_imgtype()=='16-bit' and not '16-bit' in note:
                IPy.alert('do not surport 16-bit image')
                return False
            elif ips.get_imgtype()=='float' and not 'float' in note:
                IPy.alert('do not surport float image')
                return False
        return True
        
    def preview(self, para):
        process_one(self, self.ips, self.ips.snap, self.ips.img, para, None)
        
    def load(self, ips):return True
          
    def ok(self, ips, para=None, callafter=None):
        if para == None:
            para = self.para
            if not 'not_slice' in self.note and ips.get_nslices()>1:
                if para == None:para = {}
            if para!=None and 'stack' in para:del para['stack']
        win = TextLogManager.get('Recorder')
        if ips.get_nslices()==1 or 'not_slice' in self.note:
            # process_one(self, ips, ips.snap, ips.img, para)
            print(111)
            threading.Thread(target = process_one, args = 
                (self, ips, ips.snap, ips.img, para, callafter)).start()

            '''
            run = lambda p=para:process_one(self, ips, ips.snap, ips.img, p, True)

            thread = threading.Thread(None, run, ())
            thread.start()
            if not thd:thread.join()
            '''
            if win!=None: win.append('{}>{}'.format(self.title, para))
        elif ips.get_nslices()>1:
            has, rst = 'stack' in para, None
            if not has:
                rst = IPy.yes_no('run every slice in current stacks?')
            if 'auto_snap' in self.note and self.modal:ips.reset()
            if has and para['stack'] or rst == 'yes':
                para['stack'] = True
                #process_stack(self, ips, ips.snap, ips.imgs, para)
                print(222)
                threading.Thread(target = process_stack, args = 
                    (self, ips, ips.snap, ips.imgs, para)).start()
                '''
                run = lambda p=para:process_stack(self, ips, ips.snap, ips.imgs, p)
                
                print( 'new thread')
                thread = threading.Thread(None, run, ())
                thread.start()
                if not thd:thread.join()
                '''
                
                if win!=None: win.append('{}>{}'.format(self.title, para))
            elif has and not para['stack'] or rst == 'no': 
                para['stack'] = False
                #process_one(self, ips, ips.snap, ips.img, para)
                print(333)
                threading.Thread(target = process_one, args = 
                    (self, ips, ips.snap, ips.img, para, callafter)).start()
                ''' multithread
                run = lambda p=para:process_one(self, ips, ips.snap, ips.img, p, True)
                
                thread = threading.Thread(None, run, ())
                thread.start()
                if thd:thread.join()
                '''
                if win!=None: win.append('{}>{}'.format(self.title, para))
            elif rst == 'cancel': pass
        #ips.update = 'pix'
        
    def cancel(self, ips):
        if 'auto_snap' in self.note:
            ips.swap()
            ips.update = 'pix'
            
    def start(self, para=None, callafter=None):
        ips = self.ips
        if not self.check(ips):return
        if not self.load(ips):return
        if 'auto_snap' in self.note:ips.snapshot()
        
        if para!=None or self.view==None:
            self.ok(ips, para, callafter)
        elif self.modal:
            if self.show() == wx.ID_OK:
                self.ok(ips, None, callafter)
            else:self.cancel(ips)
            self.dialog.Destroy()
        else: self.show()