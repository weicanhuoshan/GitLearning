catlog = ['filter_plgs', '-', 'Show Uniform Filter', 'Show Gaussian Filter',
 'Show Gaussian And Threshold', 'Show Gaussian In Nature', 'Show Sobel Filter',
 'Show Laplace Filter', 'Show Laplace of Gaussian', 'Show DOG Filter',
 'Show Laplace Sharp Filter', 'Show Unsharp Mask Filter',
 '-', 'Use Filter To Extract Text', 'Use Filter To Extract Text Step',
 '-', 'Show Median Filter', 'Show Max And Min Filter', 'Show Percent Filter'
]