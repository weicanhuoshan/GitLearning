catlog = ['Show Filter On Binary', 'Show Smooth The Rec', 'Show Smooth The Gear', 'Show Dog The Gear', 
'Show QRCode Art', '-', 'Show Dilation', 'Show Erosion', 'Show Open And Close', '-', 'Show Fill Holes', 
'Show Outline', 'Show ConvexHull', 'Show Skeleton', '-', 'Show Distance', 'Show Max Circle', 'Show Medial Axis', 
'Show Skeleton And MidAix', 'Show Voronoi', 'Show Binary Watershed', 'Show Repair Lines', 'Show Buffer By Distance', 
'Show Make Parabola', '-', 'Show Base Analysis', 'Show Holes Count', 'Show Region Solidity', 'Show Circle And Ellipse',
'Show Region Analysis', 'Show Region Filter', '-', 'Show Global Statistic', 'Show Mask', 'Show Label Mask',
'Show Intensity Analysis', 'Show How To Get Mask', 'Intensity Filter', 'Show The Lighter One', 
'Show The Pure One', '-', 'Show Cell Analysis', 'Show Cell With Granule', 'Show Cell Connected']