catlog = ['pixeloper_plgs', '-', 'Histogram Of Gray Image', 'Histogram Normalize And Match', 
	'Image Merge', '-', 'Color Balance Demo', 'Color Histogram Match']