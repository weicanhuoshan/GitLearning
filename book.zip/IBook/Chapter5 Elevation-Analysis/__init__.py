catlog = ['elevation_plgs', '-', 'Show Do Threshold', 'Show Do Stairs', 'Show Find Maximum', 
'Show Find Maximum', 'Show Find Watershed', 'Show Watershed Sub', 'Show Find Ridge', 
'Show Ridge Sub', '-', 'Show Find Minimum', 'Show Watershed Inv', 'Show Watershed Inv Sub']